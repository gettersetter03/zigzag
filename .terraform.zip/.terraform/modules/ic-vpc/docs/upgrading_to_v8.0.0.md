# Upgrading to v8.0.0

The v8.0 release contains backwards-incompatible changes.

This update requires upgrading the minimum provider version of `hashicorp/google` from `3.83` to `4.64` and `hashicorp/google-beta` from `3.45` to `4.64`.
