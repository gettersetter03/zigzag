# Networking Codelab

The Terraform configuration in this directory is used for a [simple codelab](https://codelabs.developers.google.com/codelabs/hashicorp-terraform-networking/index.html#0).

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

No inputs.

## Outputs

| Name | Description |
|------|-------------|
| ip | n/a |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
